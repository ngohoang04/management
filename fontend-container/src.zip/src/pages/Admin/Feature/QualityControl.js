// src/pages/Admin/Feature/QualityControl.js

import React from 'react';

const QualityControl = () => {
  return (
    <div className="quality-control-page">
      <h2>Quality Control Management</h2>
      <p>This page is currently under development.</p>
    </div>
  );
};

export default QualityControl;