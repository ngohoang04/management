import React from 'react';
import './App.css';
import AllRoutes from './components/AllRoutes/index.js';


function App() {
  return (
    <>
      <AllRoutes />

    </>
  );
}

export default App;